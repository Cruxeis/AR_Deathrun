//Deathrun Gamemode for AR
//Made by Cruxeis, BL_ID 35041

exec("./lib/classes/Armor.cs");
exec("./lib/classes/fxDTSBrick.cs");
exec("./lib/classes/GameConnection.cs");
exec("./lib/classes/Player.cs");
exec("./lib/classes/Slayer.cs");
exec("./lib/scripts/events.cs");
exec("./lib/scripts/operative.cs");
exec("./lib/scripts/serverCommands.cs");